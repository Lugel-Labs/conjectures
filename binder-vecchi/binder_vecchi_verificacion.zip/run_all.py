"""
Reproducibility script — Binder–Vecchi Conjecture 1.5 (refined Hodge–Poincaré
polynomials of matroids).  Run:  python3 run_all.py   [--full]

  1. Koszul engine (Franz: H(X_Sigma) = Tor^{Sym N^v}(Q[Sigma],Q)) vs the closed
     formula of Binder–Vecchi for uniform matroids; Euler characteristic;
     top coefficient = Möbius invariant.
  2. Cellular ("orbits as events") model vs Koszul engine, incl. non-simple
     matroids -> confirms H^i(M) = sum_b C(p,b) H^{i-b}(si M).
  3. H^i_{U(r,n)} = I_{r-1} D(f_i) and exact real-rootedness of all parallel
     extensions of uniform matroids (p <= 40).
  4. Battery of rank-4 matroids: columns, bivariate mixtures P_M(t,x),
     parallel extensions.
  5. PG(3,2): top columns (pure top 64x^3); with --full also [x^1]H^9 (~7 min).
"""
import sys, os, time, itertools, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from math import comb
from koszul import (uniform, graphic, linear, add_parallel, from_bases,
                    refined_hodge_poincare, uniform_formula, chow_FY, derangement_poly, P)
from koszul2 import build_B, koszul_columns
from cellular import refined_cellular
from rr import is_real_rooted, parallel_ext
from geoms import PG

FULL = "--full" in sys.argv
t0 = time.time()

print("== 1. Koszul engine vs Binder–Vecchi uniform formula ==")
for (r, n) in [(2, 3), (3, 4), (3, 5), (3, 6), (4, 5), (4, 6), (3, 7)]:
    H = refined_hodge_poincare(uniform(r, n), seed=7)["H"]  # asserts Euler identity inside
    assert all(H[i] == uniform_formula(r, n, i) for i in range(n - r + 1))
    assert H[0] == chow_FY(uniform(r, n))
    assert H[n - r][r - 1] == comb(n - 1, r - 1)
    print(f"  U({r},{n}) OK  {H}")

print("== 2. cellular model vs Koszul engine (non-uniform, non-simple) ==")
K4 = graphic([(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)], "M(K4)")
fano = linear([(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1)], p=2, name="Fano")
for M in [K4, fano, add_parallel(uniform(3, 4), 0, 2), add_parallel(K4, 0, 1)]:
    A = refined_hodge_poincare(M, seed=3)["H"]
    B = refined_cellular(M)
    assert A == B
    print(f"  {M.name:14s} OK  {A}")
base = refined_cellular(uniform(3, 4))
assert refined_cellular(add_parallel(uniform(3, 4), 0, 2)) == parallel_ext(base, 2)
print("  parallel-element formula H^i(M) = sum_b C(p,b) H^{i-b}(si M): OK")


def f_i(r, n, i):
    out = [0] * r
    for k in range(r):
        c = sum(comb(n - m - 1, r + i - m - 1) * comb(i + k - m - 1, i - 1) for m in range(k + 1))
        for j in range(k + 1):
            out[r - 1 - k + j] += c * comb(k, j)
    return out


def Dmap(f):
    out = [0] * (len(f) + 1)
    for m, cf in enumerate(f):
        for e, v in enumerate(derangement_poly(m)):
            out[e] += cf * v
    return out


print("== 3. uniform: H^i = I_{r-1} D(f_i); exact check of parallel extensions ==")
for r in range(2, 7):
    for n in range(r + 1, r + 6):
        for i in range(1, n - r + 1):
            g = Dmap(f_i(r, n, i))
            g = (g + [0] * r)[:r]
            assert list(reversed(g)) == uniform_formula(r, n, i)
cnt = 0
for r in range(3, 7):
    for n in range(r + 1, r + 7):
        H = [uniform_formula(r, n, i) for i in range(n - r + 1)]
        for p in range(0, 41):
            for h in parallel_ext(H, p):
                assert is_real_rooted(h)
                cnt += 1
print(f"  identity OK; {cnt} polynomials of parallel extensions of U(r,n): all real-rooted")

print("== 4. rank-4 battery (columns, bivariate mixtures, parallel extensions) ==")
AG32 = linear([(1,) + v for v in itertools.product([0, 1], repeat=3)], p=2, name="AG(3,2)")
W4 = graphic([(0, 1), (0, 2), (0, 3), (0, 4), (1, 2), (2, 3), (3, 4), (4, 1)], "M(W4)")
K5 = graphic(list(itertools.combinations(range(5), 2)), "M(K5)")
for M in [AG32, W4, K5]:
    Bd = build_B(M, seed=1)
    Hd = koszul_columns(Bd)
    H = [Hd[i] for i in range(len(Hd))]
    ok_cols = all(is_real_rooted(h) for h in H)
    worst = 0.0
    for lt in np.linspace(-4, 8, 400):
        t = 10 ** lt
        poly = [sum(t ** i * H[i][d] for i in range(len(H))) for d in range(len(H[0]))]
        rts = np.roots(list(reversed(poly)))
        worst = max(worst, float(np.max(np.abs(rts.imag) / (np.abs(rts) + 1e-300))))
    ok_par = all(is_real_rooted(h) for p in range(1, 61) for h in parallel_ext(H, p))
    print(f"  {M.name:8s} columns RR={ok_cols}  bivariate max|Im|/|z|={worst:.1e}  parallel(p<=60) RR={ok_par}")

print("== 5. PG(3,2) ==")
M = PG(4, 2)
Bd = build_B(M, seed=11)
c = Bd["c"]
H = koszul_columns(Bd, cols=[c, c - 1])
print(f"  h-vector {Bd['h']},  H^{c} = {H[c]},  H^{c-1} = {H[c-1]}")
if FULL:
    from projrank import column_coeff
    a = column_coeff(Bd, c - 2, 1, seed=101, verbose=True)
    print(f"  [x^1] H^{c-2} = {a};  edge polynomial y(64y^2+245y+{a}), disc = {245**2-4*64*a}")
print(f"done in {time.time()-t0:.0f}s")

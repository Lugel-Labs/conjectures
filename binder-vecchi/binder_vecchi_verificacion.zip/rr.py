"""exact real-rootedness tools (Sturm sequences over Q)"""
from fractions import Fraction
from math import comb
import numpy as np


def trim(p):
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return p


def pdiv(a, b):
    a = [Fraction(x) for x in a]
    b = [Fraction(x) for x in trim(b)]
    q = [Fraction(0)] * max(len(a) - len(b) + 1, 1)
    a = trim(a)
    while len(a) >= len(b) and a:
        c = a[-1] / b[-1]
        s = len(a) - len(b)
        q[s] = c
        for k in range(len(b)):
            a[s + k] -= c * b[k]
        a = trim(a)
    return trim(q), a


def pgcd(a, b):
    a, b = trim(a), trim(b)
    while b:
        _, r = pdiv(a, b)
        a, b = b, r
    lc = a[-1]
    return [x / lc for x in a]


def deriv(p):
    return [k * p[k] for k in range(1, len(p))]


def sign_changes(seq):
    s = [x for x in seq if x != 0]
    return sum(1 for u, v in zip(s, s[1:]) if (u > 0) != (v > 0))


def num_real_roots_distinct(p):
    p = trim([Fraction(x) for x in p])
    if len(p) <= 1:
        return 0
    seq = [p, deriv(p)]
    while True:
        _, r = pdiv(seq[-2], seq[-1])
        if not r:
            break
        seq.append([-x for x in r])
    # sign at -inf and +inf
    def lead_sign(q, at_plus):
        deg = len(q) - 1
        s = 1 if q[-1] > 0 else -1
        if not at_plus and deg % 2 == 1:
            s = -s
        return s
    return sign_changes([lead_sign(q, False) for q in seq]) - sign_changes([lead_sign(q, True) for q in seq])


def is_real_rooted(p):
    """exact: all complex roots of integer polynomial p are real"""
    p = trim(p)
    if len(p) <= 2:
        return True
    g = pgcd(p, deriv(p))
    sqf, _ = pdiv(p, g)  # square-free part
    sqf = trim(sqf)
    return num_real_roots_distinct(sqf) == len(sqf) - 1


def max_imag(p):
    p = trim(p)
    if len(p) <= 2:
        return 0.0
    rts = np.roots([float(c) for c in reversed(p)])
    return float(np.max(np.abs(rts.imag)))


def parallel_ext(Hs, p):
    """H^i of M with p extra parallel elements, from H^a of simplification"""
    c = len(Hs) - 1
    L = max(len(h) for h in Hs)
    out = []
    for i in range(c + p + 1):
        acc = [0] * L
        for b in range(0, min(i, p) + 1):
            a = i - b
            if a <= c:
                for d, v in enumerate(Hs[a]):
                    acc[d] += comb(p, b) * v
        out.append(acc)
    return out

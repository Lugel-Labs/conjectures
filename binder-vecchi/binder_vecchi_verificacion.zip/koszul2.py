"""
Faster Koszul engine: computes selected columns i of the Betti table
(= refined Hodge–Poincaré polynomials H^i_M) of the Stanley–Reisner ring of
the Bergman fan over Sym(N^vee), via an Artinian reduction B.
"""
import itertools, random, time
import numpy as np
from math import comb
from koszul import Matroid, rref_mod, rank_mod, matmul_mod, P


def build_B(M, seed=1, verbose=False):
    rng = random.Random(seed)
    n, r = M.n, M.r
    levels = M.flats()
    proper = [F for k in range(1, r) for F in levels[k]]
    m = len(proper)
    comp = []
    for F in proper:
        mask = 0
        for j, G in enumerate(proper):
            if (F & G) == F or (F & G) == G:
                mask |= 1 << j
        comp.append(mask)
    D = r - 1
    mons = [[()]]
    compat = [[(1 << m) - 1]]
    for d in range(1, D + 1):
        nm, nc = [], []
        for mono, cm in zip(mons[-1], compat[-1]):
            start = mono[-1] if mono else 0
            mm = cm >> start
            F = start
            while mm:
                if mm & 1:
                    nm.append(mono + (F,))
                    nc.append(cm & comp[F])
                mm >>= 1
                F += 1
        mons.append(nm)
        compat.append(nc)
    index = [{mo: k for k, mo in enumerate(L)} for L in mons]

    theta = np.zeros((n - 1, m), dtype=np.int64)
    for a in range(n - 1):
        for j, F in enumerate(proper):
            theta[a, j] = ((F >> a) & 1) - ((F >> (n - 1)) & 1)
    G = np.array([[rng.randrange(P) for _ in range(n - 1)] for _ in range(n - 1)], dtype=np.int64)
    phi = matmul_mod(G, theta % P)
    lsop, rest = phi[: r - 1], phi[r - 1:]

    def mult_matrix(form, d, rows_subset=None):
        src = range(len(mons[d])) if rows_subset is None else rows_subset
        src = list(src)
        out = np.zeros((len(src), len(mons[d + 1])), dtype=np.int64)
        nzF = [F for F in range(m) if form[F]]
        for k, s in enumerate(src):
            mono, cm = mons[d][s], compat[d][s]
            for F in nzF:
                if (cm >> F) & 1:
                    new = tuple(sorted(mono + (F,)))
                    col = index[d + 1][new]
                    out[k, col] = (out[k, col] + form[F]) % P
        return out

    red = [(np.zeros((0, 1), dtype=np.int64), [], [0])]
    hd = [1]
    for d in range(1, D + 1):
        t = time.time()
        A = np.vstack([mult_matrix(lsop[a], d - 1) for a in range(r - 1)])
        R, piv = rref_mod(A)
        ps = set(piv)
        nonpiv = [k for k in range(len(mons[d])) if k not in ps]
        red.append((R, piv, nonpiv))
        hd.append(len(nonpiv))
        if verbose:
            print(f"  B_{d}: SR dim {len(mons[d])}, h_{d} = {len(nonpiv)}  ({time.time()-t:.1f}s)")
    # h-vector check
    f = [0] * (D + 1)
    for d in range(D + 1):
        for mono in mons[d]:
            if len(set(mono)) == len(mono):
                f[len(mono)] += 1
    h = [0] * (D + 1)
    for k in range(D + 1):
        for j in range(D - k + 1):
            h[k + j] += f[k] * comb(D - k, j) * (-1) ** j
    assert hd == h, (hd, h)

    def B_mult(form, d):
        R1, piv1, nonpiv1 = red[d + 1]
        _, _, nonpiv0 = red[d]
        Mfull = mult_matrix(form, d, nonpiv0)
        if len(piv1):
            Mred = (Mfull[:, nonpiv1] - matmul_mod(Mfull[:, piv1], R1[:, nonpiv1])) % P
        else:
            Mred = Mfull[:, nonpiv1] % P
        return Mred.T

    c = n - r
    mu = {}
    for s in range(c):
        for d in range(D):
            mu[(s, d)] = B_mult(rest[s], d)
    return {"mu": mu, "h": h, "c": c, "D": D, "n": n, "r": r, "f": f}


def koszul_columns(Bdat, cols=None, verbose=False):
    mu, h, c, D = Bdat["mu"], Bdat["h"], Bdat["c"], Bdat["D"]
    if cols is None:
        cols = list(range(c + 1))
    subsets = {}
    def subs(i):
        if i not in subsets:
            L = list(itertools.combinations(range(c), i))
            subsets[i] = (L, {S: k for k, S in enumerate(L)})
        return subsets[i]

    rank_cache = {}
    def diff_rank(i, d):
        """rank of ∂: Λ^i⊗B_d -> Λ^{i-1}⊗B_{d+1}"""
        if i <= 0 or i > c or d < 0 or d + 1 > D:
            return 0
        key = (i, d)
        if key in rank_cache:
            return rank_cache[key]
        Li, _ = subs(i)
        Lm, im = subs(i - 1)
        h0, h1 = h[d], h[d + 1]
        if h0 == 0 or h1 == 0:
            rank_cache[key] = 0
            return 0
        Mx = np.zeros((len(Lm) * h1, len(Li) * h0), dtype=np.int64)
        for col, S in enumerate(Li):
            for pos, s in enumerate(S):
                T = S[:pos] + S[pos + 1:]
                row = im[T]
                blk = mu[(s, d)] if pos % 2 == 0 else (P - mu[(s, d)]) % P
                Mx[row * h1:(row + 1) * h1, col * h0:(col + 1) * h0] = blk
        t = time.time()
        if Mx.shape[0] > Mx.shape[1]:
            Mx = Mx.T.copy()
        rk = rank_mod(Mx)
        if verbose:
            print(f"    rank ∂(i={i},d={d}) {Mx.shape} = {rk}  ({time.time()-t:.1f}s)")
        rank_cache[key] = rk
        return rk

    H = {}
    for i in cols:
        row = []
        for d in range(D + 1):
            dimK = comb(c, i) * h[d]
            row.append(dimK - diff_rank(i, d) - diff_rank(i + 1, d - 1))
        H[i] = row
    return H

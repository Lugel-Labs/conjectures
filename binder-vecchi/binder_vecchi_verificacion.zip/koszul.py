"""
Refined Hodge–Poincaré polynomials  H^i_M(x)  of a loopless matroid M
(Binder; Binder–Vecchi), computed from first principles:

    H^i_M(x) = sum_j dim Tor_i^{Sym(N^vee)}( Q[Sigma_M], Q )_j  x^{j-i}

where Q[Sigma_M] is the Stanley–Reisner ring of the Bergman fan
(order complex of proper nonempty flats) and Sym(N^vee) acts through the
n-1 linear forms  theta_k = sum_{F ∋ k} x_F - sum_{F ∋ n} x_F.

Method: R = Q[Sigma] is Cohen–Macaulay of dim r-1.  Pick a generic basis
phi_1..phi_{n-1} of span(theta); phi_1..phi_{r-1} is an l.s.o.p., so
Tor^S(R,Q) = H( Koszul(phi_r..phi_{n-1}; B) ),  B = R/(phi_1..phi_{r-1}),
with the internal grading preserved.  All linear algebra is done mod a
large prime (2^31-1); results are checked against several identities.
"""
import itertools, random
import numpy as np
from math import comb

P = 2147483647  # prime 2^31-1


# ---------------------------------------------------------------- matroids
class Matroid:
    def __init__(self, n, rank_fn, name=""):
        self.n = n
        self._rank = rank_fn
        self.cache = {}
        self.E = (1 << n) - 1
        self.r = self.rank(self.E)
        self.name = name

    def rank(self, S):
        v = self.cache.get(S)
        if v is None:
            v = self._rank(S)
            self.cache[S] = v
        return v

    def closure(self, S):
        rS = self.rank(S)
        c = S
        for e in range(self.n):
            if not (S >> e) & 1 and self.rank(S | (1 << e)) == rS:
                c |= 1 << e
        return c

    def flats(self):
        F0 = self.closure(0)
        if F0 != 0:
            raise ValueError("matroid has loops")
        levels = [[0]]
        for k in range(1, self.r + 1):
            new = set()
            for F in levels[-1]:
                for e in range(self.n):
                    if not (F >> e) & 1:
                        new.add(self.closure(F | (1 << e)))
            levels.append(sorted(new))
        return levels


def popcount(x):
    return bin(x).count("1")


def uniform(r, n):
    return Matroid(n, lambda S: min(popcount(S), r), f"U({r},{n})")


def from_bases(n, bases, name=""):
    B = [sum(1 << e for e in b) for b in bases]
    return Matroid(n, lambda S: max(popcount(S & b) for b in B), name)


def _rank_mod(rows, p=P):
    """rank of a list of integer vectors mod p (small sizes)"""
    A = [list(v) for v in rows]
    if not A:
        return 0
    m = len(A[0])
    rk = 0
    for c in range(m):
        piv = None
        for i in range(rk, len(A)):
            if A[i][c] % p:
                piv = i
                break
        if piv is None:
            continue
        A[rk], A[piv] = A[piv], A[rk]
        inv = pow(A[rk][c] % p, p - 2, p)
        A[rk] = [(v * inv) % p for v in A[rk]]
        for i in range(len(A)):
            if i != rk and A[i][c] % p:
                f = A[i][c]
                A[i] = [(a - f * b) % p for a, b in zip(A[i], A[rk])]
        rk += 1
    return rk


def linear(vectors, p=P, name=""):
    """column matroid of a list of integer vectors, rank computed mod p"""
    n = len(vectors)

    def rk(S):
        return _rank_mod([vectors[e] for e in range(n) if (S >> e) & 1], p)

    return Matroid(n, rk, name)


def graphic(edges, name=""):
    n = len(edges)

    def rk(S):
        parent = {}

        def find(a):
            while parent.get(a, a) != a:
                a = parent[a]
            return a

        r = 0
        for e in range(n):
            if (S >> e) & 1:
                u, v = edges[e]
                a, b = find(u), find(v)
                if a != b:
                    parent[a] = b
                    r += 1
        return r

    return Matroid(n, rk, name)


def add_parallel(M, e, copies=1):
    """add `copies` new elements parallel to element e"""
    n0 = M.n

    def rk(S):
        base = S & ((1 << n0) - 1)
        if S >> n0:
            base |= 1 << e
        return M.rank(base)

    return Matroid(n0 + copies, rk, f"{M.name}+{copies}par")


# ------------------------------------------------------- modular linalg
def rref_mod(A):
    A = np.array(A, dtype=np.int64) % P
    rows, cols = A.shape
    piv = []
    r = 0
    for c in range(cols):
        if r == rows:
            break
        nz = np.nonzero(A[r:, c])[0]
        if len(nz) == 0:
            continue
        pr = r + nz[0]
        if pr != r:
            A[[r, pr]] = A[[pr, r]]
        inv = pow(int(A[r, c]), P - 2, P)
        A[r] = (A[r] * inv) % P
        col = A[:, c].copy()
        col[r] = 0
        nzr = np.nonzero(col)[0]
        if len(nzr):
            A[nzr] = (A[nzr] - (col[nzr, None] * A[r][None, :]) % P) % P
        piv.append(c)
        r += 1
    return A[:r], piv


def rank_mod(A):
    if A.size == 0:
        return 0
    A = A.copy() % P
    rows, cols = A.shape
    r = 0
    for c in range(cols):
        if r == rows:
            break
        nz = np.nonzero(A[r:, c])[0]
        if len(nz) == 0:
            continue
        pr = r + nz[0]
        if pr != r:
            A[[r, pr]] = A[[pr, r]]
        inv = pow(int(A[r, c]), P - 2, P)
        A[r] = (A[r] * inv) % P
        below = A[r + 1:, c].copy()
        nzr = np.nonzero(below)[0]
        if len(nzr):
            idx = nzr + r + 1
            A[idx] = (A[idx] - (below[nzr, None] * A[r][None, :]) % P) % P
        r += 1
    return r


def matmul_mod(A, B):
    """(A @ B) mod P without int64 overflow (split A into 16-bit halves)"""
    A = A % P
    B = B % P
    lo = A & 0xFFFF
    hi = A >> 16
    L = A.shape[1]
    if L == 0:
        return np.zeros((A.shape[0], B.shape[1]), dtype=np.int64)
    out = np.zeros((A.shape[0], B.shape[1]), dtype=np.int64)
    step = 30000  # keep partial sums < 2^63
    for s in range(0, L, step):
        pl = (lo[:, s:s + step] @ B[s:s + step]) % P
        ph = (hi[:, s:s + step] @ B[s:s + step]) % P
        out = (out + pl + (ph * 65536) % P) % P
    return out


# --------------------------------------------------- the main computation
def refined_hodge_poincare(M, seed=1, check=True):
    """returns dict with 'H' : list of coefficient lists, H[i][d] = coeff of x^d
    in H^i_M(x), plus auxiliary data."""
    rng = random.Random(seed)
    n, r = M.n, M.r
    levels = M.flats()
    proper = [F for k in range(1, r) for F in levels[k]]
    rkF = [k for k in range(1, r) for F in levels[k]]
    m = len(proper)
    comp = []
    for i, F in enumerate(proper):
        mask = 0
        for j, G in enumerate(proper):
            if (F & G) == F or (F & G) == G:
                mask |= 1 << j
        comp.append(mask)

    # SR monomials by degree: sorted tuples of flat indices
    maxdeg = r  # need up to degree r to certify B_r = 0
    mons = [[()]]
    compat = [[(1 << m) - 1]]
    for d in range(1, maxdeg + 1):
        nm, nc = [], []
        for mono, cm in zip(mons[-1], compat[-1]):
            start = mono[-1] if mono else 0
            for F in range(start, m):
                if (cm >> F) & 1:
                    nm.append(mono + (F,))
                    nc.append(cm & comp[F])
        mons.append(nm)
        compat.append(nc)
    index = [{mo: k for k, mo in enumerate(L)} for L in mons]

    # linear forms theta_k, k=0..n-2 ; coefficient on flat F
    theta = np.zeros((n - 1, m), dtype=np.int64)
    for a in range(n - 1):
        for j, F in enumerate(proper):
            theta[a, j] = ((F >> a) & 1) - ((F >> (n - 1)) & 1)
    G = np.array([[rng.randrange(P) for _ in range(n - 1)] for _ in range(n - 1)],
                 dtype=np.int64)
    phi = matmul_mod(G, theta % P)  # (n-1) x m
    lsop = phi[: r - 1]
    rest = phi[r - 1:]
    c = n - r

    def mult_matrix(form, d):
        """matrix of multiplication by linear form: SR_d -> SR_{d+1},
        returned as (len(SR_d) x len(SR_{d+1})) rows = images"""
        rows = np.zeros((len(mons[d]), len(mons[d + 1])), dtype=np.int64)
        for k, (mono, cm) in enumerate(zip(mons[d], compat[d])):
            for F in range(m):
                if form[F] and (cm >> F) & 1:
                    new = tuple(sorted(mono + (F,)))
                    rows[k, index[d + 1][new]] = (rows[k, index[d + 1][new]] + form[F]) % P
        return rows

    # I_d = sum_a lsop_a * SR_{d-1}
    red = [None] * (maxdeg + 1)  # (R, piv, nonpiv)
    hdims = []
    for d in range(0, maxdeg + 1):
        N = len(mons[d])
        if d == 0:
            red[0] = (np.zeros((0, 1), dtype=np.int64), [], [0])
            hdims.append(1)
            continue
        blocks = [mult_matrix(lsop[a], d - 1) for a in range(r - 1)]
        A = np.vstack(blocks) if blocks else np.zeros((0, N), dtype=np.int64)
        R, piv = rref_mod(A) if A.shape[0] else (np.zeros((0, N), dtype=np.int64), [])
        pivset = set(piv)
        nonpiv = [k for k in range(N) if k not in pivset]
        red[d] = (R, piv, nonpiv)
        hdims.append(len(nonpiv))

    # h-vector of the order complex for the check
    # f-vector: faces = chains of proper flats
    f = [0] * r  # f[k] = number of chains with k elements, k=0..r-1
    def chains(last_mask, size):
        pass
    # count chains via the monomials with all exponents 1 (squarefree)
    for d in range(0, maxdeg + 1):
        for mono in mons[d]:
            if len(set(mono)) == len(mono) and len(mono) <= r - 1:
                f[len(mono)] += 1
    D = r - 1
    h = [0] * (D + 1)
    for k in range(D + 1):
        # h(t) = sum_k f_k t^k (1-t)^{D-k}
        for j in range(D - k + 1):
            h[k + j] += f[k] * comb(D - k, j) * (-1) ** j
    if check:
        assert hdims[:D + 1] == h, (hdims, h)
        assert all(x == 0 for x in hdims[D + 1:]), hdims

    # multiplication by the remaining forms on B: B_d -> B_{d+1}
    def B_mult(form, d):
        R1, piv1, nonpiv1 = red[d + 1]
        _, _, nonpiv0 = red[d]
        Mfull = mult_matrix(form, d)[nonpiv0]  # images of basis monomials
        if len(piv1):
            Mred = (Mfull[:, nonpiv1] - matmul_mod(Mfull[:, piv1], R1[:, nonpiv1])) % P
        else:
            Mred = Mfull[:, nonpiv1] % P
        return Mred.T  # (h_{d+1} x h_d): column = image of basis vector

    mu = {}
    for s in range(c):
        for d in range(D):
            mu[(s, d)] = B_mult(rest[s], d)

    # Koszul complex on B with c forms
    subsets = [list(itertools.combinations(range(c), i)) for i in range(c + 1)]
    sidx = [{S: k for k, S in enumerate(L)} for L in subsets]

    def diff(i, d):
        """∂ : wedge^i ⊗ B_d -> wedge^{i-1} ⊗ B_{d+1}"""
        if i == 0 or d + 1 > D:
            return None
        h0, h1 = hdims[d], hdims[d + 1]
        Mx = np.zeros((len(subsets[i - 1]) * h1, len(subsets[i]) * h0), dtype=np.int64)
        for col, S in enumerate(subsets[i]):
            for pos, s in enumerate(S):
                T = S[:pos] + S[pos + 1:]
                row = sidx[i - 1][T]
                sign = 1 if pos % 2 == 0 else P - 1
                Mx[row * h1:(row + 1) * h1, col * h0:(col + 1) * h0] = \
                    (Mx[row * h1:(row + 1) * h1, col * h0:(col + 1) * h0] + sign * mu[(s, d)]) % P
        return Mx

    ranks = {}
    for i in range(c + 1):
        for d in range(D + 1):
            Mx = diff(i, d)
            ranks[(i, d)] = rank_mod(Mx) if Mx is not None and Mx.size else 0
    H = []
    for i in range(c + 1):
        row = []
        for d in range(D + 1):
            dimK = len(subsets[i]) * hdims[d]
            ker = dimK - ranks[(i, d)]
            im = ranks[(i + 1, d - 1)] if (i + 1 <= c and d - 1 >= 0) else 0
            row.append(ker - im)
        H.append(row)

    if check:
        # Euler characteristic: sum_i (-1)^i t^i H^i(t) = h(t) (1-t)^c
        lhs = [0] * (D + c + 1)
        for i in range(c + 1):
            for d in range(D + 1):
                lhs[i + d] += (-1) ** i * H[i][d]
        rhs = [0] * (D + c + 1)
        for k in range(D + 1):
            for j in range(c + 1):
                rhs[k + j] += h[k] * comb(c, j) * (-1) ** j
        assert lhs == rhs, (lhs, rhs)
    return {"H": H, "h": h, "f": f, "nflats": [len(L) for L in levels],
            "n": n, "r": r}


# ------------------------------------------------ closed-form references
def derangement_poly(j):
    """d_j(x) = sum over derangements of x^{exc}; d_0=1, d_1=0"""
    if j == 0:
        return [1]
    coeffs = [0] * (j + 1)
    for w in itertools.permutations(range(j)):
        if all(w[k] != k for k in range(j)):
            coeffs[sum(1 for k in range(j) if w[k] > k)] += 1
    return coeffs


def uniform_formula(r, n, i):
    """Binder–Vecchi Lemma 6.2 (i>=1) / FMSV formula (i=0)"""
    out = [0] * r
    for j in range(r):
        dj = derangement_poly(j)
        if i == 0:
            mult = comb(n, j)
            for a, cf in enumerate(dj):
                for s in range(r - j):
                    if a + s < r:
                        out[a + s] += mult * cf
        else:
            W = sum(comb(n, j) * comb(n - j - l, r - j - 1) * comb(n - r - l, i - 1)
                    for l in range(1, n - r - i + 2))
            for a, cf in enumerate(dj):
                e = a + r - j - 1
                if 0 <= e < r:
                    out[e] += W * cf
    return out


def chow_FY(M):
    """Chow polynomial via Feichtner–Yuzvinsky basis count"""
    levels = M.flats()
    r = M.r
    flats = [(F, k) for k in range(1, r + 1) for F in levels[k]]
    poly = [0] * r
    # dynamic programming over chains of nonempty flats, starting from empty (rank 0)
    from functools import lru_cache

    @lru_cache(None)
    def g(F, k):
        # sum over chains starting above flat F (rank k), returns polynomial list
        res = [1] + [0] * (r - 1)
        for G, kG in flats:
            if kG > k and (F & G) == F:
                gap = kG - k - 1
                if gap >= 1:
                    sub = g(G, kG)
                    for a in range(1, gap + 1):
                        for e, cf in enumerate(sub):
                            if a + e < r:
                                res[a + e] += cf
        return tuple(res)

    return list(g(0, 0))

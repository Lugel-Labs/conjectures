import time, itertools
from koszul import *
from koszul2 import build_B, koszul_columns
from cellular import refined_cellular

def PG(k, q=2):
    # projective geometry PG(k-1, q) over prime q: all nonzero vectors up to scaling
    vecs = []
    for v in itertools.product(range(q), repeat=k):
        if any(v):
            # normalize: first nonzero = 1
            fnz = next(x for x in v if x)
            if fnz == 1: vecs.append(v)
    return linear(vecs, p=q, name=f"PG({k-1},{q})")


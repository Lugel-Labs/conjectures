"""
Cellular ("events") model for the refined Hodge–Poincaré polynomials.

X = X_{Sigma_M} is stratified by torus orbits O_sigma ~ (C^*)^{n-1-dim sigma}.
For each weight the orbit spectral sequence of H_c degenerates at E_2, and
Poincaré duality gives

    [x^e] H^i_M(x) = dim H_e( C^{(a)}_• ),   a = n-1-e-i,

    C^{(a)}_e = ⊕_{cones sigma, dim sigma = e}  Λ^a (sigma^⊥),
    ∂ : Λ^a(tau^⊥) ↪ Λ^a(sigma^⊥)   (sigma facet of tau, simplicial signs).

For a chain  ∅ < F_1 < ... < F_e < E  the annihilator splits along the blocks
D_j = F_j minus F_{j-1}:   sigma^⊥ = ⊕_j Q_0^{D_j}  (zero-sum vectors on D_j).
"""
import itertools
import numpy as np
from math import comb
from koszul import Matroid, rank_mod, P, popcount


def chains_of_flats(M):
    levels = M.flats()
    r = M.r
    proper = [F for k in range(1, r) for F in levels[k]]
    m = len(proper)
    above = [[j for j, G in enumerate(proper) if G != F and (F & G) == F] for F in proper]
    chains = [[()]]
    # chains as tuples of flat indices in increasing order (by inclusion)
    cur = [(j,) for j in range(m)]
    while cur:
        chains.append(cur)
        nxt = []
        for ch in cur:
            for j in above[ch[-1]]:
                nxt.append(ch + (j,))
        cur = nxt
    return proper, chains


def blocks(M, proper, ch):
    prev = 0
    out = []
    for j in ch:
        F = proper[j]
        out.append(F & ~prev)
        prev = F
    out.append(M.E & ~prev)
    return out


def perp_basis(M, proper, ch):
    """basis of sigma^⊥ as list of (k, k0) meaning u_k - u_k0, k0 = min of block"""
    basis = []
    for D in blocks(M, proper, ch):
        els = [e for e in range(M.n) if (D >> e) & 1]
        k0 = els[0]
        for k in els[1:]:
            basis.append((k, k0))
    return basis


def refined_cellular(M):
    n, r = M.n, M.r
    proper, chains = chains_of_flats(M)
    D = r - 1  # max cone dim
    pb = {}  # chain -> basis list and index map
    for e in range(D + 1):
        for ch in chains[e]:
            b = perp_basis(M, proper, ch)
            pb[ch] = (b, {v: k for k, v in enumerate(b)})

    def express(vec, ch):
        """express u_k - u_k0 (vec) in basis of sigma^⊥ for chain ch: dict idx->coef"""
        k, k0 = vec
        b, idx = pb[ch]
        # find block containing k (and k0) in ch; basis vectors (k, min) ...
        blks = blocks(M, proper, ch)
        for Dm in blks:
            if (Dm >> k) & 1:
                assert (Dm >> k0) & 1
                mn = (Dm & -Dm).bit_length() - 1
                out = {}
                if k != mn:
                    out[idx[(k, mn)]] = out.get(idx[(k, mn)], 0) + 1
                if k0 != mn:
                    out[idx[(k0, mn)]] = out.get(idx[(k0, mn)], 0) - 1
                return out
        raise RuntimeError

    H = [[0] * (D + 1) for _ in range(n - r + 1)]
    # for each a, build complex C_e (e=0..D) and boundary maps
    for a in range(0, n):
        dims = []
        wedge_index = []
        for e in range(D + 1):
            lst = []
            idxmap = {}
            for ch in chains[e]:
                b, _ = pb[ch]
                for S in itertools.combinations(range(len(b)), a):
                    idxmap[(ch, S)] = len(lst)
                    lst.append((ch, S))
            dims.append(len(lst))
            wedge_index.append((lst, idxmap))
        if all(d == 0 for d in dims):
            continue
        ranks = [0] * (D + 2)  # ranks[e] = rank of ∂_e : C_e -> C_{e-1}
        for e in range(1, D + 1):
            src, _ = wedge_index[e]
            _, tgtmap = wedge_index[e - 1]
            if not src or dims[e - 1] == 0:
                continue
            A = np.zeros((dims[e - 1], dims[e]), dtype=np.int64)
            for col, (ch, S) in enumerate(src):
                btau, _ = pb[ch]
                for p in range(len(ch)):
                    sub = ch[:p] + ch[p + 1:]
                    sign = 1 if p % 2 == 0 else -1
                    # image of wedge of btau[S] in Λ^a(sub^⊥)
                    exprs = [express(btau[s], sub) for s in S]
                    # multilinear expansion
                    terms = {(): sign}
                    for ex in exprs:
                        new = {}
                        for tup, cf in terms.items():
                            for j, c in ex.items():
                                if j in tup:
                                    continue
                                new[tup + (j,)] = new.get(tup + (j,), 0) + cf * c
                        terms = new
                    for tup, cf in terms.items():
                        if cf == 0:
                            continue
                        # sort with sign
                        arr = list(tup)
                        sgn = 1
                        for x in range(len(arr)):
                            for y in range(len(arr) - 1 - x):
                                if arr[y] > arr[y + 1]:
                                    arr[y], arr[y + 1] = arr[y + 1], arr[y]
                                    sgn = -sgn
                        row = tgtmap[(sub, tuple(arr))]
                        A[row, col] = (A[row, col] + sgn * cf) % P
            ranks[e] = rank_mod(A)
        for e in range(D + 1):
            hom = dims[e] - ranks[e] - (ranks[e + 1] if e + 1 <= D else 0)
            i = n - 1 - e - a
            if 0 <= i <= n - r:
                H[i][e] += hom
            else:
                assert hom == 0, ("unexpected homology", a, e, hom)
    return H

"""randomized exact rank (mod P) of structured Koszul differentials
   ∂_{i,d} : Λ^i V ⊗ B_d -> Λ^{i-1} V ⊗ B_{d+1}
   rank(∂) = rank(R·∂) for random R with as many rows as cols(∂) (w.h.p.)."""
import itertools, time
import numpy as np
from math import comb
from koszul import rank_mod, matmul_mod, P


def koszul_rank_projected(Bdat, i, d, seed=0, verbose=False):
    mu, h, c, D = Bdat["mu"], Bdat["h"], Bdat["c"], Bdat["D"]
    if i <= 0 or i > c or d < 0 or d + 1 > D:
        return 0
    h0, h1 = h[d], h[d + 1]
    if h0 == 0 or h1 == 0:
        return 0
    rng = np.random.default_rng(seed)
    Li = list(itertools.combinations(range(c), i))
    Lm = list(itertools.combinations(range(c), i - 1))
    iS = {S: k for k, S in enumerate(Li)}
    iT = {T: k for k, T in enumerate(Lm)}
    R, C = len(Lm) * h1, len(Li) * h0
    t = time.time()
    if R >= C:
        # Proj = Rnd (C x R) @ A (R x C)
        Proj = np.zeros((C, C), dtype=np.int64)
        for T in Lm:
            RT = rng.integers(0, P, size=(C, h1), dtype=np.int64)
            outs = [s for s in range(c) if s not in T]
            for s in outs:
                S = tuple(sorted(T + (s,)))
                pos = S.index(s)
                blk = mu[(s, d)] if pos % 2 == 0 else (P - mu[(s, d)]) % P
                k = iS[S]
                Proj[:, k * h0:(k + 1) * h0] = (Proj[:, k * h0:(k + 1) * h0] + matmul_mod(RT, blk)) % P
    else:
        # Proj = A (R x C) @ Rnd (C x R)
        Proj = np.zeros((R, R), dtype=np.int64)
        for S in Li:
            RS = rng.integers(0, P, size=(h0, R), dtype=np.int64)
            for pos, s in enumerate(S):
                T = S[:pos] + S[pos + 1:]
                blk = mu[(s, d)] if pos % 2 == 0 else (P - mu[(s, d)]) % P
                k = iT[T]
                Proj[k * h1:(k + 1) * h1, :] = (Proj[k * h1:(k + 1) * h1, :] + matmul_mod(blk, RS)) % P
    t1 = time.time() - t
    rk = rank_mod(Proj)
    if verbose:
        print(f"    rank ∂(i={i},d={d}) full shape ({R},{C}) via proj {Proj.shape}: {rk}  "
              f"(proj {t1:.1f}s, elim {time.time()-t-t1:.1f}s)", flush=True)
    return rk


def column_coeff(Bdat, i, d, seed=0, verbose=False):
    """[x^d] H^i  =  dim(Λ^i⊗B_d) - rank ∂_{i,d} - rank ∂_{i+1,d-1}"""
    c, h = Bdat["c"], Bdat["h"]
    dimK = comb(c, i) * h[d]
    a = koszul_rank_projected(Bdat, i, d, seed, verbose)
    b = koszul_rank_projected(Bdat, i + 1, d - 1, seed + 1, verbose) if d >= 1 else 0
    return dimK - a - b

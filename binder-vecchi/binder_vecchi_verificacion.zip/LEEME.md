# Verificación — Conjetura 1.5 de Binder–Vecchi

Requiere solo Python 3 + numpy.

    python3 run_all.py          # ~1 min: todas las verificaciones rápidas
    python3 run_all.py --full   # + [x^1] H^9 de PG(3,2) (~7 min)

| archivo | qué hace |
|---|---|
| `koszul.py` | Matroides (uniformes, gráficas, lineales, paralelos) y motor de Koszul desde cero: Tor sobre Sym(N^∨) del anillo de Stanley–Reisner del abanico de Bergman (Franz), vía reducción artiniana por un s.o.p. lineal genérico. Aritmética exacta mod 2^31−1. |
| `koszul2.py` | Versión rápida, columnas seleccionadas. |
| `cellular.py` | Modelo "por eventos": complejo celular sobre las órbitas tóricas, con coeficientes Λ^a(σ^⊥), donde σ^⊥ = ⊕ Q₀^{F_j∖F_{j−1}}. |
| `projrank.py` | Rango exacto (Monte Carlo) de diferenciales de Koszul grandes por proyección aleatoria. |
| `rr.py` | Prueba exacta de raíces reales (Sturm sobre Q) y extensiones paralelas. |
| `geoms.py` | Geometrías proyectivas PG(k−1, q). |
